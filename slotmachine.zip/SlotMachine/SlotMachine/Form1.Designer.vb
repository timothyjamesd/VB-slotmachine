﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblcoins = New System.Windows.Forms.Label()
        Me.btnSpin = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.slot1timer = New System.Windows.Forms.Timer(Me.components)
        Me.slot2timer = New System.Windows.Forms.Timer(Me.components)
        Me.slot3timer = New System.Windows.Forms.Timer(Me.components)
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.lblCitiOwed = New System.Windows.Forms.Label()
        Me.lblChaseOwed = New System.Windows.Forms.Label()
        Me.lblWellsOwed = New System.Windows.Forms.Label()
        Me.lblBoaOwed = New System.Windows.Forms.Label()
        Me.tbCitiPay = New System.Windows.Forms.TextBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.tbChasePay = New System.Windows.Forms.TextBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.tbWellsPay = New System.Windows.Forms.TextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.tbBoaPay = New System.Windows.Forms.TextBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.tbCiti = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.lblCitiRate = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.tbChase = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lblChaseRate = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.tbWells = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.lblWellsRate = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.tbBOA = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblBOArate = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.pbSlot3 = New System.Windows.Forms.PictureBox()
        Me.pbSlot2 = New System.Windows.Forms.PictureBox()
        Me.pbSlot1 = New System.Windows.Forms.PictureBox()
        Me.pbBackground = New System.Windows.Forms.PictureBox()
        Me.RateTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblboaInt = New System.Windows.Forms.Label()
        Me.lblwellInt = New System.Windows.Forms.Label()
        Me.lblchaseInt = New System.Windows.Forms.Label()
        Me.lblCitiInt = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbSlot3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbSlot2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbSlot1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbBackground, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 58.75!)
        Me.Label1.Location = New System.Drawing.Point(198, 9)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(2084, 178)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "GIVE YOUR MONEY TO US"
        '
        'btnStop
        '
        Me.btnStop.Enabled = False
        Me.btnStop.Location = New System.Drawing.Point(0, 0)
        Me.btnStop.Margin = New System.Windows.Forms.Padding(6)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(224, 92)
        Me.btnStop.TabIndex = 4
        Me.btnStop.Text = "Stop Spin"
        Me.btnStop.UseVisualStyleBackColor = True
        Me.btnStop.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.25!)
        Me.Label2.Location = New System.Drawing.Point(12, 133)
        Me.Label2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(236, 57)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Place Bet"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 194)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(6)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(230, 31)
        Me.TextBox1.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.25!)
        Me.Label3.Location = New System.Drawing.Point(2, 0)
        Me.Label3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(349, 57)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Current Assets"
        '
        'lblcoins
        '
        Me.lblcoins.AutoSize = True
        Me.lblcoins.Location = New System.Drawing.Point(28, 108)
        Me.lblcoins.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblcoins.Name = "lblcoins"
        Me.lblcoins.Size = New System.Drawing.Size(0, 25)
        Me.lblcoins.TabIndex = 8
        '
        'btnSpin
        '
        Me.btnSpin.Location = New System.Drawing.Point(0, 256)
        Me.btnSpin.Margin = New System.Windows.Forms.Padding(6)
        Me.btnSpin.Name = "btnSpin"
        Me.btnSpin.Size = New System.Drawing.Size(224, 92)
        Me.btnSpin.TabIndex = 9
        Me.btnSpin.Text = "Spin"
        Me.btnSpin.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'Timer2
        '
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.lblcoins)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(202, 570)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(6)
        Me.GroupBox1.Size = New System.Drawing.Size(374, 348)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.875!)
        Me.Label6.Location = New System.Drawing.Point(51, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(264, 85)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Label6"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnStop)
        Me.GroupBox2.Controls.Add(Me.btnSpin)
        Me.GroupBox2.Location = New System.Drawing.Point(1148, 570)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(6)
        Me.GroupBox2.Size = New System.Drawing.Size(226, 348)
        Me.GroupBox2.TabIndex = 14
        Me.GroupBox2.TabStop = False
        '
        'slot1timer
        '
        '
        'slot2timer
        '
        '
        'slot3timer
        '
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.875!)
        Me.Label9.Location = New System.Drawing.Point(370, 4)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(341, 59)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "Interest Rates"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.lblCitiInt)
        Me.GroupBox4.Controls.Add(Me.lblchaseInt)
        Me.GroupBox4.Controls.Add(Me.lblwellInt)
        Me.GroupBox4.Controls.Add(Me.lblboaInt)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.lblCitiOwed)
        Me.GroupBox4.Controls.Add(Me.lblChaseOwed)
        Me.GroupBox4.Controls.Add(Me.lblWellsOwed)
        Me.GroupBox4.Controls.Add(Me.lblBoaOwed)
        Me.GroupBox4.Controls.Add(Me.tbCitiPay)
        Me.GroupBox4.Controls.Add(Me.Button8)
        Me.GroupBox4.Controls.Add(Me.tbChasePay)
        Me.GroupBox4.Controls.Add(Me.Button7)
        Me.GroupBox4.Controls.Add(Me.tbWellsPay)
        Me.GroupBox4.Controls.Add(Me.Button6)
        Me.GroupBox4.Controls.Add(Me.tbBoaPay)
        Me.GroupBox4.Controls.Add(Me.Button5)
        Me.GroupBox4.Controls.Add(Me.tbCiti)
        Me.GroupBox4.Controls.Add(Me.Button4)
        Me.GroupBox4.Controls.Add(Me.lblCitiRate)
        Me.GroupBox4.Controls.Add(Me.PictureBox4)
        Me.GroupBox4.Controls.Add(Me.tbChase)
        Me.GroupBox4.Controls.Add(Me.Button3)
        Me.GroupBox4.Controls.Add(Me.lblChaseRate)
        Me.GroupBox4.Controls.Add(Me.PictureBox3)
        Me.GroupBox4.Controls.Add(Me.tbWells)
        Me.GroupBox4.Controls.Add(Me.Button2)
        Me.GroupBox4.Controls.Add(Me.lblWellsRate)
        Me.GroupBox4.Controls.Add(Me.PictureBox2)
        Me.GroupBox4.Controls.Add(Me.tbBOA)
        Me.GroupBox4.Controls.Add(Me.Button1)
        Me.GroupBox4.Controls.Add(Me.lblBOArate)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.PictureBox1)
        Me.GroupBox4.Location = New System.Drawing.Point(1381, 200)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(1123, 808)
        Me.GroupBox4.TabIndex = 21
        Me.GroupBox4.TabStop = False
        '
        'lblCitiOwed
        '
        Me.lblCitiOwed.AutoSize = True
        Me.lblCitiOwed.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCitiOwed.Location = New System.Drawing.Point(869, 366)
        Me.lblCitiOwed.Name = "lblCitiOwed"
        Me.lblCitiOwed.Size = New System.Drawing.Size(239, 42)
        Me.lblCitiOwed.TabIndex = 51
        Me.lblCitiOwed.Text = "Money Owed"
        '
        'lblChaseOwed
        '
        Me.lblChaseOwed.AutoSize = True
        Me.lblChaseOwed.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChaseOwed.Location = New System.Drawing.Point(574, 366)
        Me.lblChaseOwed.Name = "lblChaseOwed"
        Me.lblChaseOwed.Size = New System.Drawing.Size(239, 42)
        Me.lblChaseOwed.TabIndex = 50
        Me.lblChaseOwed.Text = "Money Owed"
        '
        'lblWellsOwed
        '
        Me.lblWellsOwed.AutoSize = True
        Me.lblWellsOwed.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWellsOwed.Location = New System.Drawing.Point(282, 366)
        Me.lblWellsOwed.Name = "lblWellsOwed"
        Me.lblWellsOwed.Size = New System.Drawing.Size(239, 42)
        Me.lblWellsOwed.TabIndex = 49
        Me.lblWellsOwed.Text = "Money Owed"
        '
        'lblBoaOwed
        '
        Me.lblBoaOwed.AutoSize = True
        Me.lblBoaOwed.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBoaOwed.Location = New System.Drawing.Point(37, 366)
        Me.lblBoaOwed.Name = "lblBoaOwed"
        Me.lblBoaOwed.Size = New System.Drawing.Size(239, 42)
        Me.lblBoaOwed.TabIndex = 48
        Me.lblBoaOwed.Text = "Money Owed"
        '
        'tbCitiPay
        '
        Me.tbCitiPay.Location = New System.Drawing.Point(877, 423)
        Me.tbCitiPay.Name = "tbCitiPay"
        Me.tbCitiPay.Size = New System.Drawing.Size(171, 31)
        Me.tbCitiPay.TabIndex = 47
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(877, 460)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(171, 43)
        Me.Button8.TabIndex = 46
        Me.Button8.Text = "Pay Back"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'tbChasePay
        '
        Me.tbChasePay.Location = New System.Drawing.Point(581, 423)
        Me.tbChasePay.Name = "tbChasePay"
        Me.tbChasePay.Size = New System.Drawing.Size(171, 31)
        Me.tbChasePay.TabIndex = 45
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(581, 460)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(171, 43)
        Me.Button7.TabIndex = 44
        Me.Button7.Text = "Pay Back "
        Me.Button7.UseVisualStyleBackColor = True
        '
        'tbWellsPay
        '
        Me.tbWellsPay.Location = New System.Drawing.Point(294, 423)
        Me.tbWellsPay.Name = "tbWellsPay"
        Me.tbWellsPay.Size = New System.Drawing.Size(171, 31)
        Me.tbWellsPay.TabIndex = 43
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(294, 460)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(171, 43)
        Me.Button6.TabIndex = 42
        Me.Button6.Text = "Pay Back"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'tbBoaPay
        '
        Me.tbBoaPay.Location = New System.Drawing.Point(38, 423)
        Me.tbBoaPay.Name = "tbBoaPay"
        Me.tbBoaPay.Size = New System.Drawing.Size(171, 31)
        Me.tbBoaPay.TabIndex = 41
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(38, 460)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(171, 43)
        Me.Button5.TabIndex = 40
        Me.Button5.Text = "Pay Back"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'tbCiti
        '
        Me.tbCiti.Location = New System.Drawing.Point(877, 269)
        Me.tbCiti.Name = "tbCiti"
        Me.tbCiti.Size = New System.Drawing.Size(171, 31)
        Me.tbCiti.TabIndex = 39
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(877, 306)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(171, 43)
        Me.Button4.TabIndex = 38
        Me.Button4.Text = "Borrow"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'lblCitiRate
        '
        Me.lblCitiRate.AutoSize = True
        Me.lblCitiRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCitiRate.Location = New System.Drawing.Point(835, 221)
        Me.lblCitiRate.Name = "lblCitiRate"
        Me.lblCitiRate.Size = New System.Drawing.Size(0, 31)
        Me.lblCitiRate.TabIndex = 36
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = Global.SlotMachine.My.Resources.Resources.citibank
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Location = New System.Drawing.Point(876, 66)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(172, 131)
        Me.PictureBox4.TabIndex = 35
        Me.PictureBox4.TabStop = False
        '
        'tbChase
        '
        Me.tbChase.Location = New System.Drawing.Point(582, 269)
        Me.tbChase.Name = "tbChase"
        Me.tbChase.Size = New System.Drawing.Size(171, 31)
        Me.tbChase.TabIndex = 34
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(582, 306)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(171, 43)
        Me.Button3.TabIndex = 33
        Me.Button3.Text = "Borrow"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'lblChaseRate
        '
        Me.lblChaseRate.AutoSize = True
        Me.lblChaseRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChaseRate.Location = New System.Drawing.Point(544, 221)
        Me.lblChaseRate.Name = "lblChaseRate"
        Me.lblChaseRate.Size = New System.Drawing.Size(0, 31)
        Me.lblChaseRate.TabIndex = 31
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = Global.SlotMachine.My.Resources.Resources.chase
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(581, 66)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(172, 131)
        Me.PictureBox3.TabIndex = 30
        Me.PictureBox3.TabStop = False
        '
        'tbWells
        '
        Me.tbWells.Location = New System.Drawing.Point(294, 269)
        Me.tbWells.Name = "tbWells"
        Me.tbWells.Size = New System.Drawing.Size(171, 31)
        Me.tbWells.TabIndex = 29
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(294, 306)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(171, 43)
        Me.Button2.TabIndex = 28
        Me.Button2.Text = "Borrow"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'lblWellsRate
        '
        Me.lblWellsRate.AutoSize = True
        Me.lblWellsRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWellsRate.Location = New System.Drawing.Point(287, 221)
        Me.lblWellsRate.Name = "lblWellsRate"
        Me.lblWellsRate.Size = New System.Drawing.Size(0, 31)
        Me.lblWellsRate.TabIndex = 26
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = Global.SlotMachine.My.Resources.Resources._2000px_Wells_Fargo_Bank_svg
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(293, 66)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(172, 131)
        Me.PictureBox2.TabIndex = 25
        Me.PictureBox2.TabStop = False
        '
        'tbBOA
        '
        Me.tbBOA.Location = New System.Drawing.Point(38, 269)
        Me.tbBOA.Name = "tbBOA"
        Me.tbBOA.Size = New System.Drawing.Size(171, 31)
        Me.tbBOA.TabIndex = 24
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(38, 306)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(171, 43)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "Borrow"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lblBOArate
        '
        Me.lblBOArate.AutoSize = True
        Me.lblBOArate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBOArate.Location = New System.Drawing.Point(53, 221)
        Me.lblBOArate.Name = "lblBOArate"
        Me.lblBOArate.Size = New System.Drawing.Size(0, 31)
        Me.lblBOArate.TabIndex = 21
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.SlotMachine.My.Resources.Resources.bankofamerica
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(37, 66)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(172, 131)
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'pbSlot3
        '
        Me.pbSlot3.BackgroundImage = Global.SlotMachine.My.Resources.Resources.Koch_Industries_Logo_Wallpaper
        Me.pbSlot3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbSlot3.Location = New System.Drawing.Point(1024, 200)
        Me.pbSlot3.Margin = New System.Windows.Forms.Padding(4)
        Me.pbSlot3.Name = "pbSlot3"
        Me.pbSlot3.Size = New System.Drawing.Size(350, 348)
        Me.pbSlot3.TabIndex = 2
        Me.pbSlot3.TabStop = False
        '
        'pbSlot2
        '
        Me.pbSlot2.BackgroundImage = Global.SlotMachine.My.Resources.Resources.Pfizer_logo_1540x1026_c
        Me.pbSlot2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbSlot2.Location = New System.Drawing.Point(612, 200)
        Me.pbSlot2.Margin = New System.Windows.Forms.Padding(4)
        Me.pbSlot2.Name = "pbSlot2"
        Me.pbSlot2.Size = New System.Drawing.Size(350, 348)
        Me.pbSlot2.TabIndex = 1
        Me.pbSlot2.TabStop = False
        '
        'pbSlot1
        '
        Me.pbSlot1.BackgroundImage = Global.SlotMachine.My.Resources.Resources._1024px_National_Rifle_Association_svg
        Me.pbSlot1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbSlot1.Location = New System.Drawing.Point(202, 200)
        Me.pbSlot1.Margin = New System.Windows.Forms.Padding(4)
        Me.pbSlot1.Name = "pbSlot1"
        Me.pbSlot1.Size = New System.Drawing.Size(350, 348)
        Me.pbSlot1.TabIndex = 0
        Me.pbSlot1.TabStop = False
        '
        'pbBackground
        '
        Me.pbBackground.BackgroundImage = Global.SlotMachine.My.Resources.Resources.american_flag2
        Me.pbBackground.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbBackground.Location = New System.Drawing.Point(0, 2)
        Me.pbBackground.Margin = New System.Windows.Forms.Padding(6)
        Me.pbBackground.Name = "pbBackground"
        Me.pbBackground.Size = New System.Drawing.Size(2518, 1083)
        Me.pbBackground.TabIndex = 11
        Me.pbBackground.TabStop = False
        '
        'RateTimer
        '
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(31, 561)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(226, 42)
        Me.Label4.TabIndex = 52
        Me.Label4.Text = "Interest Paid"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(270, 561)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(226, 42)
        Me.Label5.TabIndex = 53
        Me.Label5.Text = "Interest Paid"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(558, 561)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(226, 42)
        Me.Label7.TabIndex = 54
        Me.Label7.Text = "Interest Paid"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(869, 561)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(226, 42)
        Me.Label8.TabIndex = 55
        Me.Label8.Text = "Interest Paid"
        '
        'lblboaInt
        '
        Me.lblboaInt.AutoSize = True
        Me.lblboaInt.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblboaInt.Location = New System.Drawing.Point(30, 635)
        Me.lblboaInt.Name = "lblboaInt"
        Me.lblboaInt.Size = New System.Drawing.Size(39, 42)
        Me.lblboaInt.TabIndex = 56
        Me.lblboaInt.Text = "0"
        '
        'lblwellInt
        '
        Me.lblwellInt.AutoSize = True
        Me.lblwellInt.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblwellInt.Location = New System.Drawing.Point(287, 635)
        Me.lblwellInt.Name = "lblwellInt"
        Me.lblwellInt.Size = New System.Drawing.Size(39, 42)
        Me.lblwellInt.TabIndex = 57
        Me.lblwellInt.Text = "0"
        '
        'lblchaseInt
        '
        Me.lblchaseInt.AutoSize = True
        Me.lblchaseInt.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblchaseInt.Location = New System.Drawing.Point(575, 635)
        Me.lblchaseInt.Name = "lblchaseInt"
        Me.lblchaseInt.Size = New System.Drawing.Size(39, 42)
        Me.lblchaseInt.TabIndex = 58
        Me.lblchaseInt.Text = "0"
        '
        'lblCitiInt
        '
        Me.lblCitiInt.AutoSize = True
        Me.lblCitiInt.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCitiInt.Location = New System.Drawing.Point(892, 635)
        Me.lblCitiInt.Name = "lblCitiInt"
        Me.lblCitiInt.Size = New System.Drawing.Size(39, 42)
        Me.lblCitiInt.TabIndex = 59
        Me.lblCitiInt.Text = "0"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(2516, 1127)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pbSlot3)
        Me.Controls.Add(Me.pbSlot2)
        Me.Controls.Add(Me.pbSlot1)
        Me.Controls.Add(Me.pbBackground)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbSlot3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbSlot2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbSlot1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbBackground, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pbSlot1 As PictureBox
    Friend WithEvents pbSlot2 As PictureBox
    Friend WithEvents pbSlot3 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnStop As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lblcoins As Label
    Friend WithEvents btnSpin As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents pbBackground As PictureBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents slot1timer As Timer
    Friend WithEvents slot2timer As Timer
    Friend WithEvents slot3timer As Timer
    Friend WithEvents Label6 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents tbWells As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents lblWellsRate As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents tbBOA As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents lblBOArate As Label
    Friend WithEvents tbCiti As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents lblCitiRate As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents tbChase As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents lblChaseRate As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents lblCitiOwed As Label
    Friend WithEvents lblChaseOwed As Label
    Friend WithEvents lblWellsOwed As Label
    Friend WithEvents lblBoaOwed As Label
    Friend WithEvents tbCitiPay As TextBox
    Friend WithEvents Button8 As Button
    Friend WithEvents tbChasePay As TextBox
    Friend WithEvents Button7 As Button
    Friend WithEvents tbWellsPay As TextBox
    Friend WithEvents Button6 As Button
    Friend WithEvents tbBoaPay As TextBox
    Friend WithEvents Button5 As Button
    Friend WithEvents RateTimer As Timer
    Friend WithEvents lblCitiInt As Label
    Friend WithEvents lblchaseInt As Label
    Friend WithEvents lblwellInt As Label
    Friend WithEvents lblboaInt As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
End Class
