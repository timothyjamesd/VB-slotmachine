﻿Public Class Form1
    Dim coins As Integer = 100
    Dim bet As Integer
    Dim slot1 As Integer
    Dim slot2 As Integer
    Dim slot3 As Integer
    Dim slot1stop As Boolean = True
    Dim slot2stop As Boolean = True
    Dim slot3stop As Boolean = True
    Dim slot1value As Integer
    Dim slot2value As Integer
    Dim slot3value As Integer
    Dim stopit As Boolean
    Dim testnumber As Integer = 0
    Dim time As Integer = 15
    Dim time2 As Integer = 6
    Dim time3 As Integer = 8
    Dim time4 As Integer = 8
    Dim time5 As Integer = 9
    Dim time6 As Integer = 35
    Dim BoaRate As Double
    Dim WellsRate As Double
    Dim ChaseRate As Double
    Dim CitiRate As Double
    Dim BoaBorrow As Integer = 0
    Dim WellsBorrow As Integer = 0
    Dim CitiBorrow As Integer = 0
    Dim ChaseBorrow As Integer = 0
    Dim wellsOwed As Integer = 0
    Dim boaOwed As Integer = 0
    Dim chaseOwed As Integer = 0
    Dim citiOwed As Integer = 0
    Dim BoaOwing As Boolean = False
    Dim WellsOwing As Boolean = False
    Dim ChaseOwing As Boolean = False
    Dim CitiOwing As Boolean = False
    Dim boaPay As Integer
    Dim wellsPay As Integer
    Dim chasePay As Integer
    Dim citiPay As Integer
    Dim boaIntPaid As Integer
    Dim wellsIntPaid As Integer
    Dim chaseIntPaid As Integer
    Dim citiIntPaid As Integer



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer2.Enabled = True
        Label6.Text = coins
        RateTimer.Enabled = True
    End Sub

    Private Sub btnSpin_Click(sender As Object, e As EventArgs) Handles btnSpin.Click
        Timer1.Enabled = True
        bet = TextBox1.Text
        slot2timer.Enabled = True
        slot1timer.Enabled = True
        slot3timer.Enabled = True


    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        Randomize()


        btnStop.Enabled = False
            btnStop.Visible = False
            stopit = True
            slot2timer.Enabled = False
            slot1timer.Enabled = False
            slot3timer.Enabled = False
        slot1 = Int(Rnd() * 8 + 2)
        slot2 = Int(Rnd() * 8 + 2)
        slot3 = Int(Rnd() * 8 + 2)

        coins = coins - bet
            If slot1 = 1 Then
                pbSlot1.BackgroundImage = My.Resources.bp_logo
                slot1value = 7
            End If
            If slot1 = 2 Then
                pbSlot1.BackgroundImage = My.Resources.exxon_mobil
                slot1value = 3
            End If
            If slot1 = 3 Then
                pbSlot1.BackgroundImage = My.Resources.hal_logo_red_640x640
                slot1value = 5
            End If
            If slot1 = 4 Then
                pbSlot1.BackgroundImage = My.Resources.Koch_Industries_Logo_Wallpaper
                slot1value = 2

            End If
            If slot1 = 5 Then
                pbSlot1.BackgroundImage = My.Resources.Microsoft_Logo1
                slot1value = 1
            End If
            If slot1 = 6 Then
                pbSlot1.BackgroundImage = My.Resources.Pfizer_logo_1540x1026_c
                slot1value = 6
            End If
            If slot1 = 7 Then
                pbSlot1.BackgroundImage = My.Resources.PGE_logo
                slot1value = 4
            End If
            If slot1 = 8 Then
                pbSlot1.BackgroundImage = My.Resources._1024px_National_Rifle_Association_svg
                slot1value = 8
            End If


            If slot2 = 1 Then
                pbSlot2.BackgroundImage = My.Resources.bp_logo
                slot2value = 7
            End If
            If slot2 = 2 Then
                pbSlot2.BackgroundImage = My.Resources.exxon_mobil
                slot2value = 3
            End If
            If slot2 = 3 Then
                pbSlot2.BackgroundImage = My.Resources.hal_logo_red_640x640
                slot2value = 5
            End If
            If slot2 = 4 Then
                pbSlot2.BackgroundImage = My.Resources.Koch_Industries_Logo_Wallpaper
                slot2value = 2
            End If
            If slot2 = 5 Then
                pbSlot2.BackgroundImage = My.Resources.Microsoft_Logo1
                slot2value = 1
            End If
            If slot2 = 6 Then
                pbSlot2.BackgroundImage = My.Resources.Pfizer_logo_1540x1026_c
                slot2value = 6
            End If
            If slot2 = 7 Then
                pbSlot2.BackgroundImage = My.Resources.PGE_logo
                slot2value = 4
            End If
            If slot2 = 8 Then
                pbSlot2.BackgroundImage = My.Resources._1024px_National_Rifle_Association_svg
                slot2value = 8
            End If

            If slot3 = 1 Then
                pbSlot3.BackgroundImage = My.Resources.bp_logo
                slot3value = 7
            End If
            If slot3 = 2 Then
                pbSlot3.BackgroundImage = My.Resources.exxon_mobil
                slot3value = 3
            End If
            If slot3 = 3 Then
                pbSlot3.BackgroundImage = My.Resources.hal_logo_red_640x640
                slot3value = 5
            End If
            If slot3 = 4 Then
                pbSlot3.BackgroundImage = My.Resources.Koch_Industries_Logo_Wallpaper
                slot3value = 2
            End If
            If slot3 = 5 Then
                pbSlot3.BackgroundImage = My.Resources.Microsoft_Logo1
                slot3value = 1
            End If
            If slot3 = 6 Then
                pbSlot3.BackgroundImage = My.Resources.Pfizer_logo_1540x1026_c
                slot3value = 6
            End If
            If slot3 = 7 Then
                pbSlot3.BackgroundImage = My.Resources.PGE_logo
                slot3value = 4
            End If
            If slot3 = 8 Then
                pbSlot3.BackgroundImage = My.Resources._1024px_National_Rifle_Association_svg
                slot3value = 8
            End If

            '''''this is for only two of the slots being the same 
            If (slot1value = 1 And slot2value = 1) Or (slot2value And slot3value = 1) Or (slot3value = 1 And slot1value = 1) Then
                coins = coins + (bet * 5)
            End If

            If (slot1value = 2 And slot2value = 2) Or (slot2value = 2 And slot3value = 2) Or (slot1value = 1 And slot3value = 1) Then
                coins = coins + (bet * 10)
            End If

            If (slot1value = 3 And slot2value = 3) Or (slot2value = 3 And slot3value = 3) Or (slot1value = 3 And slot3value = 3) Then
                coins = coins + (bet * 15)
            End If

            If (slot1value = 4 And slot2value = 4) Or (slot2value = 4 And slot3value = 4) Or (slot1value = 4 And slot3value = 4) Then
                coins = coins + (bet * 20)
            End If

            If (slot1value = 5 And slot2value = 5) Or (slot2value = 5 And slot3value = 5) Or (slot1value = 5 And slot3value = 5) Then
                coins = coins + (bet * 25)
            End If

            If (slot1value = 6 And slot2value = 6) Or (slot2value = 6 And slot3value = 6) Or (slot1value = 6 And slot3value = 6) Then
                coins = coins + (bet * 30)
            End If

            If (slot1value = 7 And slot2value = 7) Or (slot2value = 7 And slot3value = 7) Or (slot1value = 7 And slot3value = 7) Then
                coins = coins + (bet * 35)
            End If

            If (slot1value = 8 And slot2value = 8) Or (slot2value = 8 And slot3value = 8) Or (slot1value = 8 And slot3value = 8) Then
                coins = coins + (bet * 45)
            End If



            ''''''this is for all three slots being the same
            If slot1value = 1 And slot2value = 1 And slot3value = 1 Then
                coins = coins + (bet * 10)
            End If

            If slot1value = 2 And slot2value = 2 And slot3value = 2 Then
                coins = coins + (bet * 20)
            End If

            If slot1value = 3 And slot2value = 3 And slot3value = 3 Then
                coins = coins + (bet * 30)
            End If

            If slot1value = 4 And slot2value = 4 And slot3value = 4 Then
                coins = coins + (bet * 40)
            End If

            If slot1value = 5 And slot2value = 5 And slot3value = 5 Then
                coins = coins + (bet * 50)
            End If

            If slot1value = 6 And slot2value = 6 And slot3value = 6 Then
                coins = coins + (bet * 60)
            End If

            If slot1value = 7 And slot2value = 7 And slot3value = 7 Then
                coins = coins + (bet * 70)
            End If

            If slot1value = 8 And slot2value = 8 And slot3value = 8 Then
                coins = coins + (bet * 8)
            End If

        Label6.Text = coins
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        time = time - 1


        If time <= 0 Then
            stopit = False
            Timer1.Enabled = False

            btnStop.Enabled = True
            btnStop.Visible = True
            time = 15
        End If


    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        time2 = time2 - 1



        If time2 = 6 Then
            pbBackground.BackgroundImage = My.Resources.american_flag
        End If
        If time2 = 5 Then
            pbBackground.BackgroundImage = My.Resources.american_flag
        End If
        If time2 = 4 Then
            pbBackground.BackgroundImage = My.Resources.american_flag
        End If
        If time2 = 3 Then
            pbBackground.BackgroundImage = My.Resources.american_flag2
        End If
        If time2 = 2 Then
            pbBackground.BackgroundImage = My.Resources.american_flag2
        End If
        If time2 = 1 Then
            pbBackground.BackgroundImage = My.Resources.american_flag2
        End If



        If time2 <= 0 Then

            Timer2.Enabled = True
            time2 = 6
        End If
    End Sub


    Private Sub slot1timer_Tick(sender As Object, e As EventArgs) Handles slot1timer.Tick
        time3 = time3 - 1

        If time3 = 1 Then
            pbSlot1.BackgroundImage = My.Resources.bp_logo
        End If
        If time3 = 2 Then
            pbSlot1.BackgroundImage = My.Resources.exxon_mobil
        End If
        If time3 = 3 Then
            pbSlot1.BackgroundImage = My.Resources.hal_logo_red_640x640
        End If
        If time3 = 4 Then
            pbSlot1.BackgroundImage = My.Resources.Koch_Industries_Logo_Wallpaper
        End If
        If time3 = 5 Then
            pbSlot1.BackgroundImage = My.Resources.Microsoft_Logo1
        End If
        If time3 = 6 Then
            pbSlot1.BackgroundImage = My.Resources.Pfizer_logo_1540x1026_c
        End If
        If time3 = 7 Then
            pbSlot1.BackgroundImage = My.Resources.PGE_logo
        End If
        If time3 = 8 Then
            pbSlot1.BackgroundImage = My.Resources._1024px_National_Rifle_Association_svg
        End If

        If time3 <= 0 Then
            slot1timer.Enabled = True
            time3 = 8
        End If
    End Sub

    Private Sub slot2timer_Tick(sender As Object, e As EventArgs) Handles slot2timer.Tick
        time4 = time4 - 1

        If time4 = 3 Then
            pbSlot2.BackgroundImage = My.Resources.bp_logo
        End If
        If time4 = 4 Then
            pbSlot2.BackgroundImage = My.Resources.exxon_mobil
        End If
        If time4 = 5 Then
            pbSlot2.BackgroundImage = My.Resources.hal_logo_red_640x640
        End If
        If time4 = 8 Then
            pbSlot2.BackgroundImage = My.Resources.Koch_Industries_Logo_Wallpaper
        End If
        If time4 = 7 Then
            pbSlot2.BackgroundImage = My.Resources.Microsoft_Logo1
        End If
        If time4 = 6 Then
            pbSlot2.BackgroundImage = My.Resources.Pfizer_logo_1540x1026_c
        End If
        If time4 = 2 Then
            pbSlot2.BackgroundImage = My.Resources.PGE_logo
        End If
        If time4 = 1 Then
            pbSlot2.BackgroundImage = My.Resources._1024px_National_Rifle_Association_svg
        End If

        If time4 <= 0 Then
            slot2timer.Enabled = True
            time4 = 8
        End If
    End Sub

    Private Sub slot3timer_Tick(sender As Object, e As EventArgs) Handles slot3timer.Tick
        time5 = time5 - 1

        If time5 = 8 Then
            pbSlot3.BackgroundImage = My.Resources.bp_logo
        End If
        If time5 = 7 Then
            pbSlot3.BackgroundImage = My.Resources.exxon_mobil
        End If
        If time5 = 4 Then
            pbSlot3.BackgroundImage = My.Resources.hal_logo_red_640x640
        End If
        If time5 = 3 Then
            pbSlot3.BackgroundImage = My.Resources.Koch_Industries_Logo_Wallpaper
        End If
        If time5 = 6 Then
            pbSlot3.BackgroundImage = My.Resources.Microsoft_Logo1
        End If
        If time5 = 5 Then
            pbSlot3.BackgroundImage = My.Resources.Pfizer_logo_1540x1026_c
        End If
        If time5 = 2 Then
            pbSlot3.BackgroundImage = My.Resources.PGE_logo
        End If
        If time5 = 1 Then
            pbSlot3.BackgroundImage = My.Resources._1024px_National_Rifle_Association_svg
        End If

        If time5 <= 0 Then
            slot3timer.Enabled = True
            time5 = 8
        End If
    End Sub

    Private Sub Chart1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub GroupBox4_Enter(sender As Object, e As EventArgs) Handles GroupBox4.Enter

    End Sub

    Private Sub RateTimer_Tick(sender As Object, e As EventArgs) Handles RateTimer.Tick
        time6 = time6 - 1

        '''''''returning the text back to black'''''
        If time6 = 15 Then
            lblBOArate.ForeColor = Color.Black
            lblWellsRate.ForeColor = Color.Black
            lblChaseRate.ForeColor = Color.Black
            lblCitiRate.ForeColor = Color.Black
        End If


        ''''''' setting the interest rates of each bank
        If time6 = 15 Then
            If BoaOwing = False Then
                BoaRate = Rnd() * 5
            End If
            If WellsOwing = False Then
                WellsRate = Rnd() * 5
            End If

            If ChaseOwing = False Then
                ChaseRate = Rnd() * 5
            End If

            If CitiOwing = False Then
                CitiRate = Rnd() * 5
            End If

            lblBOArate.Text = BoaRate
            lblWellsRate.Text = WellsRate
            lblChaseRate.Text = ChaseRate
            lblCitiRate.Text = CitiRate

            '''''''' changing the colors of the interest rates to indicate the best and worst option''''

            ''''''showing the worst rate''''''
            If BoaRate > WellsRate And BoaRate > ChaseRate And BoaRate > CitiRate Then
                lblBOArate.ForeColor = Color.Red
            End If

            If WellsRate > BoaRate And WellsRate > ChaseRate And WellsRate > CitiRate Then
                lblWellsRate.ForeColor = Color.Red
            End If

            If ChaseRate > BoaRate And WellsRate < ChaseRate And ChaseRate > CitiRate Then
                lblChaseRate.ForeColor = Color.Red
            End If

            If CitiRate > BoaRate And CitiRate > ChaseRate And WellsRate < CitiRate Then
                lblCitiRate.ForeColor = Color.Red
            End If
            ''''''showing the best rate''''''

            If BoaRate < WellsRate And BoaRate < ChaseRate And BoaRate < CitiRate Then
                lblBOArate.ForeColor = Color.Green
            End If

            If WellsRate < BoaRate And WellsRate < ChaseRate And WellsRate < CitiRate Then
                lblWellsRate.ForeColor = Color.Green
            End If

            If ChaseRate < BoaRate And WellsRate > ChaseRate And ChaseRate < CitiRate Then
                lblChaseRate.ForeColor = Color.Green
            End If

            If CitiRate < BoaRate And CitiRate < ChaseRate And WellsRate > CitiRate Then
                lblCitiRate.ForeColor = Color.Green
            End If
        End If

        If time6 <= 0 Then
                time6 = 35
                RateTimer.Enabled = True
            End If


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ''''''Borrowing from bank of america

        BoaBorrow = tbBOA.Text
        coins = coins + BoaBorrow
        Label6.Text = coins
        boaOwed = boaOwed + BoaBorrow
        lblBoaOwed.Text = boaOwed
        BoaOwing = True


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        '''''' Borrowing from Wells Fargo

        WellsBorrow = tbWells.Text
        coins = coins + WellsBorrow
        Label6.Text = coins
        wellsOwed = wellsOwed + WellsBorrow
        lblWellsOwed.Text = wellsOwed
        WellsOwing = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        '''''''Borrowing from chase
        ChaseBorrow = tbChase.Text
        coins = coins + ChaseBorrow
        Label6.Text = coins
        chaseOwed = chaseOwed + ChaseBorrow
        lblChaseOwed.Text = chaseOwed
        ChaseOwing = True
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        '''''''' Borrowing from citi
        CitiBorrow = tbCiti.Text
        coins = coins + CitiBorrow
        Label6.Text = coins
        citiOwed = citiOwed + CitiBorrow
        lblCitiOwed.Text = citiOwed
        CitiOwing = True
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        '''''pay back boa''''''
        boaPay = tbBoaPay.Text
        boaOwed = boaOwed - boaPay
        coins = coins - boaPay
        Label6.Text = coins
        lblBoaOwed.Text = boaOwed
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        ''''''' paying back wells fargo'''''''
        wellsPay = tbWellsPay.Text
        wellsOwed = wellsOwed - wellsPay
        coins = coins - wellsPay
        Label6.Text = coins
        lblWellsOwed.Text = wellsOwed
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        '''''' paying back chase 
        chasePay = tbChasePay.Text
        chaseOwed = chaseOwed - chasePay
        coins = coins - chasePay
        Label6.Text = coins
        lblChaseOwed.Text = chaseOwed
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        '''''' paying back citi'''''''
        citiPay = tbCitiPay.Text
        citiOwed = citiOwed - citiPay
        coins = coins - citiPay
        Label6.Text = coins
        lblCitiOwed.Text = citiOwed
    End Sub
End Class
